package hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;

/**
 * Unused atm
 *
 * Author: SafariJohn
 */
public class Roider_PhasenetTowed extends BaseHullMod {

}
