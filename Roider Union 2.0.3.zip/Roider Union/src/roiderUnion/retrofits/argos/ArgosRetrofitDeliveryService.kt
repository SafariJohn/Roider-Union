package roiderUnion.retrofits.argos

import retroLib.impl.BaseRetrofitDeliveryService

class ArgosRetrofitDeliveryService : BaseRetrofitDeliveryService(null) {
    override val isInstantOnly: Boolean = true
}