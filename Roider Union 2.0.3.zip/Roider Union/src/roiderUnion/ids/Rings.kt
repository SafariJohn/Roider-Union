package roiderUnion.ids

object Rings {
    val ASTEROIDS_0 = RingTexture(Categories.MISC, "rings_asteroids0", 256f, 4)
    val DUST_0 = RingTexture(Categories.MISC, "rings_dust0", 256f, 4)
    val ICE_0 = RingTexture(Categories.MISC, "rings_ice0", 256f, 4)
}