package hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;

// Copied from SCY_armorChild

public class Roider_MIDAS_Armor extends BaseHullMod {

    private static final String ID = "roider_MIDAS_Armor";

    // Not needed
//    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
//        stats.getKineticDamageTakenMult().modifyMult(ID, 1f - Roider_MIDAS.KINETIC_REDUCTION / 100f);
//    }

    @Override
    public void advanceInCombat(ShipAPI ship, float amount) {

        if (Global.getCombatEngine().getTotalElapsedTime(false) <= 2.05 && Global.getCombatEngine().getTotalElapsedTime(false) > 2) {
            if (ship.getParentStation() != null && ship.getParentStation().isAlive()) {

                ShipAPI parent = ship.getParentStation();
                MutableShipStatsAPI sStats = ship.getMutableStats();
                MutableShipStatsAPI pStats = parent.getMutableStats();

                float hull = ship.getHullSpec().getHitpoints();
                hull *= pStats.getHullBonus().getBonusMult();
                hull += pStats.getHullBonus().getFlatBonus();
                hull = hull / ship.getHullSpec().getHitpoints();

                sStats.getHullDamageTakenMult().modifyMult(ID, pStats.getHullDamageTakenMult().getModifiedValue() + hull);

                float armor = ship.getHullSpec().getArmorRating();
                armor *= pStats.getArmorBonus().getBonusMult();
                armor += pStats.getArmorBonus().getFlatBonus();
                armor = armor / ship.getHullSpec().getArmorRating();

                sStats.getHullDamageTakenMult().modifyMult(ID, pStats.getHullDamageTakenMult().getModifiedValue() + armor);

                sStats.getBallisticWeaponRangeBonus().modifyMult(ID, pStats.getBallisticWeaponRangeBonus().getBonusMult());
                sStats.getBallisticWeaponRangeBonus().modifyFlat(ID, pStats.getBallisticWeaponRangeBonus().getFlatBonus());

                sStats.getEnergyWeaponRangeBonus().modifyMult(ID, pStats.getEnergyWeaponRangeBonus().getBonusMult());
                sStats.getEnergyWeaponRangeBonus().modifyFlat(ID, pStats.getEnergyWeaponRangeBonus().getFlatBonus());

                sStats.getBeamWeaponRangeBonus().modifyMult(ID, pStats.getBeamWeaponRangeBonus().getBonusMult());
                sStats.getBeamWeaponRangeBonus().modifyFlat(ID, pStats.getBeamWeaponRangeBonus().getFlatBonus());

                sStats.getAutofireAimAccuracy().modifyMult(ID, pStats.getAutofireAimAccuracy().computeMultMod());

                sStats.getFragmentationDamageTakenMult().modifyMult(ID, pStats.getFragmentationDamageTakenMult().getModifiedValue());
                sStats.getEnergyDamageTakenMult().modifyMult(ID, pStats.getEnergyDamageTakenMult().getModifiedValue());
                sStats.getKineticDamageTakenMult().modifyMult(ID, pStats.getKineticDamageTakenMult().getModifiedValue());
                sStats.getHighExplosiveDamageTakenMult().modifyMult(ID, pStats.getHighExplosiveDamageTakenMult().getModifiedValue());
            }
        }
    }
}
