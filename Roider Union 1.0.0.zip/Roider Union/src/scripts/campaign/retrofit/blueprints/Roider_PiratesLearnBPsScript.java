package scripts.campaign.retrofit.blueprints;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.EconomyAPI.EconomyUpdateListener;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.impl.campaign.DelayedBlueprintLearnScript;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import java.io.IOException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import static scripts.campaign.retrofit.Roider_UnionHQRetrofitManager.MASTER_MOD;

/**
 * Author: SafariJohn
 */
public class Roider_PiratesLearnBPsScript implements EconomyUpdateListener {
    private final FactionAPI faction;
    private final Map<String, List<String>> sources;

    public Roider_PiratesLearnBPsScript(FactionAPI faction) {
        this.faction = faction;
        sources = getSources();
    }

    @Override
    public void economyUpdated() {
        for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
            SubmarketAPI submarket = market.getSubmarket(Submarkets.SUBMARKET_BLACK);
            if (submarket == null) continue;

            CargoAPI cargo = submarket.getCargo();
            if (cargo == null) continue;

            delayedLearnBlueprintsFromTransaction(faction, cargo, 60f + 60 * (float) Math.random());
        }
    }

	public void delayedLearnBlueprintsFromTransaction(FactionAPI faction, CargoAPI cargo, float daysDelay) {
		DelayedBlueprintLearnScript script = new DelayedBlueprintLearnScript(faction.getId(), daysDelay);

		for (CargoStackAPI stack : cargo.getStacksCopy()) {
			SpecialItemPlugin plugin = stack.getPlugin();
			if (plugin instanceof Roider_RetrofitBlueprintPlugin) {
				Roider_RetrofitBlueprintPlugin bp = (Roider_RetrofitBlueprintPlugin) plugin;

                String id = bp.getProvidedShip();
                if (faction.knowsShip(id)) continue;
                if (!sourceKnown(id)) continue;
                script.getShips().add(id);
                cargo.removeItems(stack.getType(), stack.getData(), 1);
			}
		}

		if (!script.getFighters().isEmpty() || !script.getShips().isEmpty()) {
			Global.getSector().addScript(script);
			cargo.sort();
		}
	}

    private boolean sourceKnown(String hullId) {
        List<String> rSources = sources.get(hullId);
        if (rSources == null) return false;

        for (String source : rSources) {
            if (faction.knowsShip(source)) return true;
        }

        return false;
    }

    private Map<String, List<String>> getSources() {
        Map<String, List<String>> rSources = new HashMap<>();
        org.json.JSONArray csv = null;

        try {
            csv = Global.getSettings().getMergedSpreadsheetDataForMod("id", "data/retrofit/retrofits.csv", MASTER_MOD);
        } catch (IOException | JSONException ex) {
            Logger.getLogger(Roider_RetrofitBlueprintPlugin.class.getName()).log(Level.SEVERE, null, ex);
            return new HashMap<>();
        }

        Set<String> targets = new HashSet<>();

        try {
            for (int i = 0; i < csv.length(); i++) {
                JSONObject o = csv.getJSONObject(i);
                targets.add(o.getString("target"));
            }

            for (String target : targets) {
                List<String> sourceList = new ArrayList<>();
                for (int i = 0; i < csv.length(); i++) {
                    JSONObject o = csv.getJSONObject(i);
                    if (target.equals(o.getString("target"))) {
                        sourceList.add(o.getString("source"));
                    }
                }
                rSources.put(target, sourceList);
            }
        } catch (JSONException ex) {
            Logger.getLogger(Roider_RetrofitBlueprintPlugin.class.getName()).log(Level.SEVERE, null, ex);
        }

        return rSources;
    }

    @Override
    public void commodityUpdated(String commodityId) {}

    @Override
    public boolean isEconomyListenerExpired() {
        return false;
    }
}
