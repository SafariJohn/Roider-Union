package roiderUnion.combat.entropyAmp

class EntropyAmpLRModel {
    var canShowFloatyText = false
    var isTargetOutOfRange = false
    var isTargetInRange = false
    var targetData: EntropyAmpLRStats.TargetData? = null
}
