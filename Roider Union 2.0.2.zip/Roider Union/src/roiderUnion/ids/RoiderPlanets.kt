package roiderUnion.ids

object RoiderPlanets {
    const val LAVA_MINOR = "lava_minor"
    const val FROZEN_3 = "frozen3"
    const val BARREN = "barren"
    const val BARREN_DESERT = "barren-desert"
    const val CRYOVOLCANIC = "cryovolcanic"
    const val GAS_GIANT = "gas_giant"
    const val ICE_GIANT = "ice_giant"
}