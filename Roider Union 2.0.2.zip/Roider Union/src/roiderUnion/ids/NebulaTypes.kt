package roiderUnion.ids

object NebulaTypes {
    const val OLD = "nebula_center_old"
    const val AVERAGE = "nebula_center_average"
    const val YOUNG = "nebula_center_young"
}