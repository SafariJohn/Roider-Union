package scripts;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.intel.bar.PortsideBarData;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.BaseBarEvent;
import exerelin.campaign.SectorManager;
import org.dark.shaders.light.LightData;
import org.dark.shaders.util.ShaderLib;
import org.dark.shaders.util.TextureData;
import scripts.campaign.Roider_FringeStationCleaner;
import scripts.campaign.bases.Roider_RoiderBaseManager;
import scripts.campaign.intel.bar.Roider_RetrofitBarEvent;
import scripts.campaign.retrofit.blueprints.Roider_PiratesLearnBPsScript;
import scripts.world.Roider_Gen;

public class Roider_ModPlugin extends BaseModPlugin {
    public static boolean hasNexerelin = false;

    @Override
    public void onApplicationLoad() {
        boolean hasLazyLib = Global.getSettings().getModManager().isModEnabled("lw_lazylib");
        if (!hasLazyLib) throw new RuntimeException("The Roider Union requires LazyLib!");

        boolean hasGraphicsLib = Global.getSettings().getModManager().isModEnabled("shaderLib");
        if (hasGraphicsLib) {
            ShaderLib.init();
            LightData.readLightDataCSV("data/lights/roider_light_data.csv");
            TextureData.readTextureDataCSV("data/lights/roider_texture_data.csv");
        }

        hasNexerelin = Global.getSettings().getModManager().isModEnabled("nexerelin");

        boolean hasfastsave = Global.getSettings().getModManager().isModEnabled("fastsave");
        if (hasfastsave) throw new RuntimeException("The Roider Union is not compatible with the Fast Save mod!");
    }


    @Override
    public void onNewGame() {
		if (!hasNexerelin || SectorManager.getManager().isCorvusMode()) {
            SectorAPI sector = Global.getSector();

            Roider_Gen.generate(sector);

//            if (!sector.hasScript(Roider_IndieRepMatcher.class)) {
//                sector.addScript(new Roider_IndieRepMatcher());
//            }
        }
    }

    @Override
    public void onNewGameAfterEconomyLoad() {
        SectorAPI sector = Global.getSector();

		if (!hasNexerelin || SectorManager.getManager().isCorvusMode()) {

            Roider_Gen.addCoreDives(sector);

            Roider_Gen.assignCustomAdmins();
            Roider_Gen.assignRandomAdmins();
        }

        Roider_Gen.placeFringeRoiderHQs(sector);

        if (!sector.hasScript(Roider_RoiderBaseManager.class)) {
            sector.addScript(new Roider_RoiderBaseManager());
        }

        if (!sector.hasScript(Roider_PiratesLearnBPsScript.class)) {
            sector.getEconomy().addUpdateListener(new Roider_PiratesLearnBPsScript(Global.
                        getSector().getFaction(Factions.PIRATES)));
        }

        BaseBarEvent event = new Roider_RetrofitBarEvent();
        PortsideBarData.getInstance().addEvent(event);
    }

    @Override
    public void onNewGameAfterTimePass() {
        if (hasNexerelin && !SectorManager.getManager().isCorvusMode()) {
            Roider_Gen.addNexRandomModeDives();
            Roider_Gen.addNexRandomRockpiper();
        }
    }

    @Override
    public void onGameLoad(boolean newGame) {
        if (!newGame) {
            Roider_FringeStationCleaner.removeOrphanedFringeStations(Global.getSector());
        }
    }
}