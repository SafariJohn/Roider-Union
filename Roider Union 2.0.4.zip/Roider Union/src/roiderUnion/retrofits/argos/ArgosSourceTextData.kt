package roiderUnion.retrofits.argos

import retroLib.impl.SourceTextData

class ArgosSourceTextData(val data: SourceTextData, val rezCosts: Map<String, Int>) {
}