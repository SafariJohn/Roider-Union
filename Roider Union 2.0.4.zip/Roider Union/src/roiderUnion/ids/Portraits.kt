package roiderUnion.ids

object Portraits {
    const val MRP_MALE = "roider_madRockpiperMale"
    const val MRP_FEMALE = "roider_madRockpiperFemale"
    const val MAGGIE = "roider_maggie"
}