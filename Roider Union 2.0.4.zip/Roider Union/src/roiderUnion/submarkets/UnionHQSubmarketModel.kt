package roiderUnion.submarkets

import roiderUnion.helpers.ExternalStrings

class UnionHQSubmarketModel {
    var tooltipAppendix = UnionHQTooltipAppendix.OTHER
    var factionName = ExternalStrings.DEBUG_NULL
    var reqName: String? = null
    var commissionRequired = false
}
