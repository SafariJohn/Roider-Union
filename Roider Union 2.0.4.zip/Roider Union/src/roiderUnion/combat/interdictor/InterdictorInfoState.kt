package roiderUnion.combat.interdictor

enum class InterdictorInfoState {
    DEFAULT,
    READY,
    OUT_OF_RANGE,
    NO_TARGET
}