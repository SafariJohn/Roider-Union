package roiderUnion.combat.phasenet

enum class PhasenetInfoState {
    ACTIVE,
    COOLDOWN,
    READY,
    OUT_OF_RANGE,
    NO_TARGET
}