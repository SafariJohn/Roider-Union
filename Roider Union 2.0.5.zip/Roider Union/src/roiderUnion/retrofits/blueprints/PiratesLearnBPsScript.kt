package roiderUnion.retrofits.blueprints

import com.fs.starfarer.api.campaign.CargoAPI
import com.fs.starfarer.api.campaign.FactionAPI
import com.fs.starfarer.api.campaign.SpecialItemPlugin
import com.fs.starfarer.api.campaign.econ.EconomyAPI
import com.fs.starfarer.api.impl.campaign.DelayedBlueprintLearnScript
import com.fs.starfarer.api.impl.campaign.ids.Submarkets
import com.thoughtworks.xstream.XStream
import retroLib.RetrofitsKeeper
import retroLib.impl.BaseRetrofitAdjuster
import roiderUnion.helpers.Helper
import roiderUnion.ids.Aliases
import roiderUnion.retrofits.RoiderAllFilter

/**
 * Author: SafariJohn
 */
class PiratesLearnBPsScript(private val faction: FactionAPI) : EconomyAPI.EconomyUpdateListener {
    companion object {
        fun alias(x: XStream) {
            val jClass = PiratesLearnBPsScript::class.java
            x.alias(Aliases.PIRLRNBP, jClass)
            x.aliasAttribute(jClass, "faction", "f")
        }
    }
    @Transient
    private var sources: Map<String, List<String>>
    @Transient
    private var sourcesUpdated: Boolean

    init {
        sources = getSources()
        sourcesUpdated = false
    }

    override fun economyUpdated() {
        Helper.sector?.economy?.marketsCopy?.forEach {
            it.getSubmarket(Submarkets.SUBMARKET_BLACK)?.cargo?.apply {
                delayedLearnBlueprintsFromTransaction(faction, this, 60f + 60f * Helper.random.nextFloat())
            }
        }
        sourcesUpdated = false
    }

    private fun delayedLearnBlueprintsFromTransaction(faction: FactionAPI, cargo: CargoAPI, daysDelay: Float) {
        val script = DelayedBlueprintLearnScript(faction.id, daysDelay)
        for (stack in cargo.stacksCopy) {
            val plugin: SpecialItemPlugin = stack.plugin ?: continue
            if (plugin is RetrofitBlueprintPlugin) {
                val id: String = plugin.providedShip ?: continue
                if (faction.knowsShip(id)) continue
                if (!sourceKnown(id)) continue
                script.ships.add(id)
                cargo.removeItems(stack.type, stack.data, 1f)
            }
        }
        if (script.fighters.isNotEmpty() || script.ships.isNotEmpty()) {
            Helper.sector?.addScript(script)
            cargo.sort()
        }
    }

    private fun sourceKnown(hullId: String): Boolean {
        if (!sourcesUpdated) {
            sources = getSources()
            sourcesUpdated = true
        }
        return sources[hullId]?.any { faction.knowsShip(it) } == true
    }

    private fun getSources(): Map<String, List<String>> {
        val results= mutableMapOf<String, List<String>>()
        val targets = mutableSetOf<String>()
        val retrofits = RetrofitsKeeper.getRetrofits(RoiderAllFilter(BaseRetrofitAdjuster(null)))
        retrofits.forEach { targets.add(it.target) }
        targets.forEach { target -> results[target] = retrofits.filter { it.target == target }.map { it.source } }
        return results
    }

    override fun commodityUpdated(commodityId: String) {}
    override fun isEconomyListenerExpired(): Boolean = false
}