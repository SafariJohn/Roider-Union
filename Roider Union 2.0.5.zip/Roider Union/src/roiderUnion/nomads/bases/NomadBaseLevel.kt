package roiderUnion.nomads.bases

enum class NomadBaseLevel {
    STARTING,
    ESTABLISHED,
    BATTLESTATION,
    SHIPWORKS,
    HQ,
    CAPITAL
}