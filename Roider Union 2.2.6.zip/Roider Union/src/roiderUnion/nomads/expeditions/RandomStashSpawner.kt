package roiderUnion.nomads.expeditions

import com.fs.starfarer.api.EveryFrameScript

class RandomStashSpawner : EveryFrameScript {
    override fun advance(amount: Float) {

    }

    override fun isDone(): Boolean = false
    override fun runWhilePaused(): Boolean = false
}