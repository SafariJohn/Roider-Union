package roiderUnion.ids

object Icons {
    const val NOMAD_BASE = "roider_base"
    const val CAT_UI = "ui"
    const val ENGINE_BOOST = "icon_tactical_engine_boost"
    const val NEBULA = "icon_tactical_nebula"
}