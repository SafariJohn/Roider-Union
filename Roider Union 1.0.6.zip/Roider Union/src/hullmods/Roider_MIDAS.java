package hullmods;


import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FleetDataAPI;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.MutableFleetStatsAPI;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidImpact;
import ids.Roider_Ids.Roider_Hullmods;

/**
 * Author: SafariJohn
 */
public class Roider_MIDAS extends BaseHullMod implements HullModFleetEffect {
    public static final String MOD_ID = "roider_MIDAS_impact";
    public static final float MAX_IMPACT_RESIST = 90f;
    public static final float KINETIC_REDUCTION = 10f;
    public static final float MASS_BONUS = 10f;

    MutableShipStatsAPI stats;
    // Resist impacts from asteroid belts and fields on the campaign map
    // Modified from MesoTroniK's TiandongRetrofit hullmod
    public void advanceInCampaign(CampaignFleetAPI fleet) {
        // Want to resist asteroid impacts
        // Must increase terrain mitigation stat during impact event
        // But not if in some other movement affecting terrain such as nebulae
        FleetDataAPI fleetData = fleet.getFleetData();
        MutableFleetStatsAPI fleetStats = fleetData.getFleet().getStats();
        MutableStat nav = fleet.getCommanderStats().getDynamic().getStat(Stats.NAVIGATION_PENALTY_MULT);

        if (!fleet.hasScriptOfClass(AsteroidImpact.class)) {
            nav.unmodifyMult(MOD_ID);
            return;
        }

//        HashMap<String, StatMod> mods = fleetStats.getFleetwideMaxBurnMod().getMultBonuses();
//        float magnitude = 1f;

//        for (Map.Entry<String, StatMod> mod : mods.entrySet()) {
//            StatMod statMod = mod.getValue();
//            if (statMod.desc == null) continue;
//
//            if (statMod.desc.contentEquals("Inside asteroid belt")
//                        || statMod.desc.contentEquals("Inside asteroid field")) {
//                asteroidMod = statMod;
//            } else {
//                continue;
//            }
//
//            magnitude *= asteroidMod.getValue();
//        }

        float contributingSize = 0f;
        float totalSize = 0f;
        for (FleetMemberAPI fleetMember : fleetData.getMembersListCopy()) {
            // Lurking NoClassDefFoundError...
            // No idea what is going on, so just going to catch it and continue.
            try {
                float size;
                switch (fleetMember.getHullSpec().getHullSize()) {
                    case FIGHTER:
                    case FRIGATE:
                    default:
                        size = 1f;
                        break;
                    case DESTROYER:
                        size = 2f;
                        break;
                    case CRUISER:
                        size = 4f;
                        break;
                    case CAPITAL_SHIP:
                        size = 8f;
                        break;
                }
                totalSize += size;
                if (hasMIDAS(fleetMember.getVariant())) {
                    contributingSize += size;
                }
            } catch (NoClassDefFoundError er) {
                Global.getLogger(Roider_MIDAS.class).error(er);
            }
        }

        float contribution = contributingSize / totalSize;
        float magnitudeMult = 1f - contribution * (1f - MAX_IMPACT_RESIST / 100f);
        nav.modifyMult(MOD_ID, magnitudeMult, "MIDAS");
    }

    private boolean hasMIDAS(ShipVariantAPI variant) {
        return variant.hasHullMod(Roider_Hullmods.MIDAS)
                    || variant.hasHullMod(Roider_Hullmods.MIDAS_1)
                    || variant.hasHullMod(Roider_Hullmods.MIDAS_2)
                    || variant.hasHullMod(Roider_Hullmods.MIDAS_3);
    }

    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        stats.getKineticDamageTakenMult().modifyMult(MOD_ID, 1f - KINETIC_REDUCTION / 100f);
    }

    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        ship.setMass(ship.getMass() * (1f + MASS_BONUS / 100f));
    }


    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) return "" + (int) MAX_IMPACT_RESIST + "%";
        if (index == 1) return "" + (int) KINETIC_REDUCTION + "%";
        if (index == 2) return "" + (int) MASS_BONUS + "%";
        return null;
    }

    @Override
    public boolean isApplicableToShip(ShipAPI ship) {
        if (ship.getVariant().hasHullMod(Roider_Hullmods.MIDAS)) return true;

        return !hasMIDAS(ship.getVariant());
    }

    @Override
    public void onFleetSync(CampaignFleetAPI fleet) {
    }
}
