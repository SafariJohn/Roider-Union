package scripts.campaign.rulecmd;

import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
import com.fs.starfarer.api.util.Misc;
import ids.Roider_Ids.Roider_Factions;
import java.util.List;
import java.util.Map;

/**
 * Author: SafariJohn
 */
public class Roider_FreeFringeWarning extends BaseCommandPlugin {
	private InteractionDialogAPI dialog;
	private SectorEntityToken entity;
	private Map<String, MemoryAPI> memoryMap;

    @Override
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) {
		this.dialog = dialog;
		this.memoryMap = memoryMap;

		String command = params.get(0).getString(memoryMap);
		if (command == null) return false;

		entity = dialog.getInteractionTarget();

        switch (command) {
            case "isFringeHQSystem": return isFringeUnionHQSystem();
        }

        return true;
    }

    private boolean isFringeUnionHQSystem() {
//        MemoryAPI sourceMem = memoryMap.get(MemKeys.SOURCE_MARKET);
        MarketAPI source = entity.getMarket();

        if (source != null) {
            return entity.getFaction().getId().equals(Roider_Factions.ROIDER_UNION)
                        && source.isHidden();

//            return sourceMem.getBoolean(Roider_MemFlags.FRINGE_HQ);
        }

        return false;
    }

}
