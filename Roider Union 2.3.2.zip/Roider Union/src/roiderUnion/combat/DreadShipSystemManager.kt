package roiderUnion.combat

import com.fs.starfarer.api.combat.CombatEngineAPI
import com.fs.starfarer.api.combat.EveryFrameCombatPlugin
import com.fs.starfarer.api.combat.ShipSystemAPI
import com.fs.starfarer.api.combat.ViewportAPI
import com.fs.starfarer.api.input.InputEventAPI
import roiderUnion.helpers.Helper
import roiderUnion.ids.RoiderIds
import java.awt.Color

class DreadShipSystemManager : EveryFrameCombatPlugin {
    companion object {
        private val DREAD_SYSTEMS = listOf(
            RoiderIds.ShipSystems.DREAD_LOADERS,
            RoiderIds.ShipSystems.DREAD_DAMPER
        )

        private val ACTIVE_STATES = mutableMapOf<String, Float>()

        val GLOW_COLOR = Color(255, 0, 0, 255)
    }

    override fun advance(amount: Float, events: MutableList<InputEventAPI>?) {
        if (Helper.combatEngine?.isPaused == true) return
        for (ship in Helper.combatEngine?.ships ?: emptyList()) {
            if (!ACTIVE_STATES.containsKey(ship.id) && ship.system?.isChargeup == true && DREAD_SYSTEMS.contains(ship.system?.id)) {
                ACTIVE_STATES[ship.id] = 0f
            }
            if (ship.system?.isChargedown == true && ACTIVE_STATES.containsKey(ship.id)) {
                ACTIVE_STATES.remove(ship.id)
                return
            }
            if (ACTIVE_STATES.containsKey(ship.id) && ship.system?.isChargeup != true) {
                val progress = if (ship.isPhased) ACTIVE_STATES[ship.id]!! else ACTIVE_STATES[ship.id]!! + amount
                val duration = ship.system?.chargeActiveDur ?: 5f
                if (progress <= duration) ship.system?.forceState(ShipSystemAPI.SystemState.ACTIVE, progress / duration)
                ACTIVE_STATES[ship.id] = progress
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun init(engine: CombatEngineAPI?) {}
    override fun processInputPreCoreControls(amount: Float, events: MutableList<InputEventAPI>?) {}
    override fun renderInWorldCoords(viewport: ViewportAPI?) {}
    override fun renderInUICoords(viewport: ViewportAPI?) {}
}