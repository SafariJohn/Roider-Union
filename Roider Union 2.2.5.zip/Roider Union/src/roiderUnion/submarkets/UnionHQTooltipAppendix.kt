package roiderUnion.submarkets

enum class UnionHQTooltipAppendix {
    NOT_FUNCTIONAL,
    LOW_REP,
    SNEAK,
    OTHER
}