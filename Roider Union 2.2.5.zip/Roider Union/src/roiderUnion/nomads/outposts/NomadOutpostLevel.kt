package roiderUnion.nomads.outposts

enum class NomadOutpostLevel {
    CLAIM,
    SITE,
    OUTPOST
}