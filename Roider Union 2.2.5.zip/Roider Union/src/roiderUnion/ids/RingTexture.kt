package roiderUnion.ids

class RingTexture(
    val category: String,
    val textureId: String,
    val width: Float,
    textures: Int
) {
    val maxIndex = textures - 1
}