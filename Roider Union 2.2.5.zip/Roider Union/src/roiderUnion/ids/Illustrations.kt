package roiderUnion.ids

object Illustrations {
    const val IND_MEGAFACILITY = "industrial_megafacility"
    const val SPACE_WRECKAGE = "space_wreckage"
    const val ORBITAL = "orbital"
    const val HOUND_HANGAR = "hound_hangar"
    const val ORBITAL_CONSTRUCTION = "orbital_construction"
}