package hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.util.Misc;
import exerelin.campaign.AllianceManager;
import exerelin.campaign.PlayerFactionStore;
import exerelin.utilities.NexUtilsFaction;
import ids.Roider_Ids.Roider_Factions;
import ids.Roider_Ids.Roider_Hullmods;
import scripts.Roider_ModPlugin;

/**
 * Author: SafariJohn
 */
public class Roider_EVAExpertise extends BaseHullMod {
	public static final float REPAIR_BONUS = 20f;
	public static final float CASUALTY_REDUCTION = 20f;
    private static final String CC_HULLMOD = "CHM_commission";

    @Override
    public void applyEffectsBeforeShipCreation(ShipAPI.HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getCombatEngineRepairTimeMult().modifyMult(id, 1f - REPAIR_BONUS * 0.01f);
		stats.getCombatWeaponRepairTimeMult().modifyMult(id, 1f - REPAIR_BONUS * 0.01f);
		stats.getCrewLossMult().modifyMult(id, 1f - CASUALTY_REDUCTION * 0.01f);
    }

    // This whole method should be redundant already.
    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        boolean alliedWithRoiders = false;
        String commissionFaction = Misc.getCommissionFactionId();
        if (Roider_ModPlugin.hasNexerelin) {
            commissionFaction = NexUtilsFaction.getCommissionFactionId();
            if (commissionFaction != null && AllianceManager.areFactionsAllied(commissionFaction, Roider_Factions.ROIDER_UNION)) {
                alliedWithRoiders = true;
            }
            if (AllianceManager.areFactionsAllied(PlayerFactionStore.getPlayerFactionId(), Roider_Factions.ROIDER_UNION)) {
                alliedWithRoiders = true;
            }
        }

        boolean roiderCommission = commissionFaction != null
                    && commissionFaction.equals(Roider_Factions.ROIDER_UNION);

        if (!alliedWithRoiders && !roiderCommission) {
            ship.getVariant().removeMod(Roider_Hullmods.EVA_EXPERTISE);
            return;
        }


        if (ship.getVariant().getHullMods().contains(CC_HULLMOD)) {
            ship.getVariant().removeMod(CC_HULLMOD);
        }
    }

	public String getDescriptionParam(int index, ShipAPI.HullSize hullSize) {
		if (index == 0) return "" + (int) REPAIR_BONUS + "%";
		if (index == 1) return "" + (int) CASUALTY_REDUCTION + "%";
		return null;
	}

}
