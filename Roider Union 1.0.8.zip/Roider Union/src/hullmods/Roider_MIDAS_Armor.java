package hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import data.scripts.util.MagicIncompatibleHullmods;
import ids.Roider_Ids.Roider_Hullmods;

// Copied from SCY_armorChild and modified

public class Roider_MIDAS_Armor extends BaseHullMod {

    private static final String ID = "roider_MIDAS_Armor";

    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        if (ship.getVariant().hasHullMod(Roider_Hullmods.EXTREME_MODS)) {
            MagicIncompatibleHullmods.removeHullmodWithWarning(ship.getVariant(),
                    Roider_Hullmods.EXTREME_MODS, Roider_Hullmods.MIDAS_ARMOR);
        }

        if (ship.getVariant().hasHullMod(Roider_Hullmods.FIGHTER_CLAMPS)) {
            MagicIncompatibleHullmods.removeHullmodWithWarning(ship.getVariant(),
                    Roider_Hullmods.FIGHTER_CLAMPS, Roider_Hullmods.MIDAS_ARMOR);
        }
    }

    @Override
    public void advanceInCombat(ShipAPI ship, float amount) {

        if (Global.getCombatEngine().getTotalElapsedTime(false) <= 2.05 && Global.getCombatEngine().getTotalElapsedTime(false) > 2) {
            if (ship.getParentStation() != null && ship.getParentStation().isAlive()) {

                ShipAPI parent = ship.getParentStation();
                MutableShipStatsAPI sStats = ship.getMutableStats();
                MutableShipStatsAPI pStats = parent.getMutableStats();

                float hull = ship.getHullSpec().getHitpoints();
                hull *= pStats.getHullBonus().getBonusMult();
                hull += pStats.getHullBonus().getFlatBonus();
                hull = ship.getHullSpec().getHitpoints() / hull;

                sStats.getHullDamageTakenMult().modifyMult(ID + "_0", pStats.getHullDamageTakenMult().getModifiedValue());
                sStats.getHullDamageTakenMult().modifyMult(ID + "_1", hull);

                float armor = ship.getHullSpec().getArmorRating();
                armor *= pStats.getArmorBonus().getBonusMult();
                armor += pStats.getArmorBonus().getFlatBonus();
                armor = ship.getHullSpec().getArmorRating() / armor;

                sStats.getArmorDamageTakenMult().modifyMult(ID + "_0", pStats.getArmorDamageTakenMult().getModifiedValue());
                sStats.getArmorDamageTakenMult().modifyMult(ID + "_1", armor);

//                sStats.getBallisticWeaponRangeBonus().modifyMult(ID, pStats.getBallisticWeaponRangeBonus().getBonusMult());
//                sStats.getBallisticWeaponRangeBonus().modifyFlat(ID, pStats.getBallisticWeaponRangeBonus().getFlatBonus());
//
//                sStats.getEnergyWeaponRangeBonus().modifyMult(ID, pStats.getEnergyWeaponRangeBonus().getBonusMult());
//                sStats.getEnergyWeaponRangeBonus().modifyFlat(ID, pStats.getEnergyWeaponRangeBonus().getFlatBonus());
//
//                sStats.getBeamWeaponRangeBonus().modifyMult(ID, pStats.getBeamWeaponRangeBonus().getBonusMult());
//                sStats.getBeamWeaponRangeBonus().modifyFlat(ID, pStats.getBeamWeaponRangeBonus().getFlatBonus());
//
//                sStats.getAutofireAimAccuracy().modifyMult(ID, pStats.getAutofireAimAccuracy().computeMultMod());

                sStats.getFragmentationDamageTakenMult().modifyMult(ID, pStats.getFragmentationDamageTakenMult().getModifiedValue());
                sStats.getEnergyDamageTakenMult().modifyMult(ID, pStats.getEnergyDamageTakenMult().getModifiedValue());
                sStats.getKineticDamageTakenMult().modifyMult(ID, pStats.getKineticDamageTakenMult().getModifiedValue());
                sStats.getHighExplosiveDamageTakenMult().modifyMult(ID, pStats.getHighExplosiveDamageTakenMult().getModifiedValue());
                sStats.getEmpDamageTakenMult().modifyMult(ID, pStats.getEmpDamageTakenMult().getModifiedValue());
            }
        }
    }
}
