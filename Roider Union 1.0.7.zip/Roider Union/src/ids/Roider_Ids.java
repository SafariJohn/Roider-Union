package ids;

/**
 * Author: SafariJohn
 */
public class Roider_Ids {
    public static final String DESC = "_desc"; // Appended to an entity's ID get its descriptions.csv ID

    public static class Roider_Hullmods {
        public static final String MIDAS = "roider_midas";
        public static final String MIDAS_1 = "roider_midas1";
        public static final String MIDAS_2 = "roider_midas2";
        public static final String MIDAS_3 = "roider_midas3";
        public static final String MIDAS_ARMOR = "roider_midas_armor";
        public static final String FIRESTORM_MOD = "roider_firestormmod";
        public static final String EVA_EXPERTISE = "roider_commissionCrew";
        public static final String DTC = "roider_bombardmentmod";
        public static final String FIGHTER_CLAMPS = "roider_fighterClamps";

        public static final String EXTREME_MODS = "swp_extrememods";
    }

    public static class Roider_Factions {
        public static final String ROIDER_UNION = "roider";
        public static final String THI = "tiandong";
    }

    public static class Roider_Fitters {
        public static final String FULL = "roider_full";
        public static final String LIGHT = "roider_light";
    }

    public static class Roider_FleetTypes {
        public static final String MINER = "roider_miner";
        public static final String MINING_FLEET = "roider_mining_fleet";
        public static final String MINING_ARMADA = "roider_mining_armada";

        public static final String PATROL_SMALL = "roider_patrolSmall";
        public static final String PATROL_MEDIUM = "roider_patrolMedium";
        public static final String PATROL_LARGE = "roider_patrolLarge";
    }

    public static class Roider_Industries {
        public static final String DIVES = "roider_dives";
        public static final String UNION_HQ = "roider_union_hq";
    }

    public static class Roider_Ranks {
        public static final String POST_BASE_COMMANDER = "roider_baseCommander";
    }

    public static class Roider_Submarkets {
        public static final String UNION_MARKET = "roider_unionMarket";
        public static final String RESUPPLY_MARKET = "roider_resupplyMarket";
        public static final String FRINGE_OPEN_MARKET = "roider_fringeMarket";
        public static final String FRINGE_BLACK_MARKET = "roider_fringeBlackMarket";
    }

    public static class Roider_Tags {
        public static final String ROID_MINING = "roider_mining";
        public static final String UNION_HQ = "roider_union_hq";
    }

    // Used for system entities
    public static class IdName {
        public final String id;
        public final String name;

        public IdName(String id, String name) {
            this.id = id;
            this.name = name;
        }

        @Override
        public String toString() {
            return id;
        }
    }
}
