package roiderUnion.roidMining

import com.fs.starfarer.api.EveryFrameScript

class NPCProspecting : EveryFrameScript {
    override fun isDone(): Boolean {
        TODO("Not yet implemented")
    }

    override fun runWhilePaused(): Boolean {
        TODO("Not yet implemented")
    }

    override fun advance(amount: Float) {
        TODO("Not yet implemented")
    }
}