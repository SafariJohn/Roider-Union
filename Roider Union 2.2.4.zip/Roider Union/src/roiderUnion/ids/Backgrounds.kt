package roiderUnion.ids

object Backgrounds {
    const val STARS_1 = "graphics/backgrounds/background2.jpg"
    const val STARS_2 = "graphics/backgrounds/background4.jpg"
    const val NEBULA_OLD = "graphics/backgrounds/background6.jpg"
    const val NEBULA_1 = "graphics/backgrounds/background1.jpg"
    const val NEBULA_2 = "graphics/backgrounds/background3.jpg"
    const val NEBULA_YOUNG = "graphics/backgrounds/background5.jpg"
    const val HYPER = "graphics/backgrounds/hyperspace1.jpg"
}