package roiderUnion.ids.hullmods

/**
 * Commissioned Crews hullmods
 */
object CCHullmods {
    const val COM = "CHM_commission"
    const val COM2 = "CHM_commission2"
    const val ALLIANCE = "CHM_alliance"
    const val ALLIANCE2 = "CHM_alliance2"
    const val LEAGUE = "CHM_persean_league"
    const val TRITACHYON = "CHM_tritachyon"
    const val SINDRIAN = "CHM_sindrian"
    const val SINDRIAN1 = "CHM_sindrian1"
    const val SINDRIAN2 = "CHM_sindrian2"
    const val SINDRIAN3 = "CHM_sindrian3"
    const val PIRATE = "CHM_pirate"
    const val CHURCH = "CHM_luddic_church"
    const val PATH = "CHM_pather"
}