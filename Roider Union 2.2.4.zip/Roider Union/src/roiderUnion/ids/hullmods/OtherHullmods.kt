package roiderUnion.ids.hullmods

object OtherHullmods {
    const val SHIELD_BYPASS = "swp_shieldbypass"
    const val EXTREME_MODS = "swp_extrememods"
    const val ILK_SENSOR_SUITE = "ilk_SensorSuite"
}