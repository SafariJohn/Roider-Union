package roiderUnion.nomads.old

class GatheringFleetData(val startingFP: Float) {
    var currFP = startingFP
}
