package roiderUnion.nomads.old.bases

enum class NomadBaseLevel {
    BASIC,
    ORBITAL,
    BATTLESTATION,
    STAR_FORT // only used for Union replacement capital
}