package roiderUnion.ids.hullmods

/**
 * Vanilla hullmods
 */
object VHullmods {
    const val RANGEFINDER = "ballistic_rangefinder"
    const val FLUX_SHUNT = "fluxshunt"
    const val HIGH_MAINTENANCE = "high_maintenance"
    const val DELICATE_SUBSYSTEMS = "delicate"
    const val CONVERTED_FIGHTER_BAY = "converted_fighterbay"
}