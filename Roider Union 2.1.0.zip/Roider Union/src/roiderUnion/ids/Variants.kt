package roiderUnion.ids

object Variants {
    const val HOUND_STARFARER = "roider_hound_Starfarer"
    const val HOUND_D_P_STANDARD = "hound_d_pirates_Standard"
    const val BUFFALO_FS = "buffalo2_FS"
    const val LASHER_D_CS = "lasher_d_CS"
    const val MUDSKIPPER2_HELL = "mudskipper2_Hellbore"
    const val MUDSKIPPER2_CS = "mudskipper2_CS"
    const val CYCLOPS_E_OUTDATED = "roider_cyclops_early_Outdated"
    const val CYCLOPS_E_BALANCED = "roider_cyclops_early_Balanced"
    const val TEMPEST_PURSUIT = "roider_tempest_Pursuit"
    const val WOLF_PURSUIT = "roider_wolf_Pursuit"
    const val WOLF_D_P_ATTACK = "wolf_d_pirates_Attack"
    const val COWBOY_BALANCED = "roider_cowboy_Balanced"
    const val TRAILBOSS_SUPPORT = "roider_trailboss_Support"
    const val RANCH_ATTACK = "roider_ranch_Attack"
    const val PEPPERBOX_ESCORT = "roider_pepperbox_Escort"
    const val FALCON_P_STRIKE = "falcon_p_Strike"
    const val COLOSSUS_3_PIRATE = "colossus3_Pirate"
    const val CONDOR_STRIKE = "condor_Strike"
    const val CONDOR_ATTACK = "condor_Attack"
    const val GAMBIT_E_SALVAGED = "roider_gambit_early_Salvaged"
}