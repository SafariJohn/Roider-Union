package roiderUnion.helpers

import com.fs.starfarer.api.campaign.CampaignFleetAPI
import com.fs.starfarer.api.campaign.CampaignUIAPI
import com.fs.starfarer.api.campaign.SectorEntityToken
import com.fs.starfarer.api.campaign.econ.MarketAPI
import com.fs.starfarer.api.impl.campaign.ids.Submarkets
import com.fs.starfarer.api.impl.campaign.intel.deciv.DecivTracker
import com.fs.starfarer.api.impl.campaign.population.CoreImmigrationPluginImpl
import com.fs.starfarer.api.util.Misc
import org.lazywizard.lazylib.MathUtils
import roiderUnion.ids.AICores

object MarketHelper {
    fun setStorageMarket(market: MarketAPI, primaryEntity: SectorEntityToken) {
        market.isHidden = true
        market.surveyLevel = MarketAPI.SurveyLevel.FULL
        market.isPlanetConditionMarketOnly = false
        market.addSubmarket(Submarkets.SUBMARKET_STORAGE)
        primaryEntity.memoryWithoutUpdate["\$tradeMode"] = CampaignUIAPI.CoreUITradeMode.NONE
        market.econGroup = market.id
        market.memoryWithoutUpdate[DecivTracker.NO_DECIV_KEY] = true
    }

    fun setPrimaryEntity(market: MarketAPI, entity: SectorEntityToken) {
        market.primaryEntity = entity
        entity.market = market
    }

    fun attachEntity(market: MarketAPI, entity: SectorEntityToken) {
        market.connectedEntities += entity
        entity.market = market
    }

    fun getStationFleet(market: MarketAPI): CampaignFleetAPI? {
        return Misc.getStationFleet(market)
    }

    fun addAICoreToIndustry(market: MarketAPI, core: AICores, industry: String) {
        if (!market.hasIndustry(industry)) return
        market.getIndustry(industry).aiCoreId = core.id
    }

    fun setPopulation(market: MarketAPI, popSize: Int) {
        val test = MathUtils.clamp(popSize, 3, Misc.MAX_COLONY_SIZE)
        while (market.size > test) CoreImmigrationPluginImpl.reduceMarketSize(market)
        while (market.size < test) CoreImmigrationPluginImpl.increaseMarketSize(market)
    }

    fun addIndustry(market: MarketAPI, id: String) {
        if (market.hasIndustry(id)) return
        market.addIndustry(id)
    }

    /**
     * @return whether the replacement industry has been added
     */
    fun replaceIndustry(market: MarketAPI?, id: String, replaceId: String? = null): Boolean {
        if (market == null) return false
        if (market.hasIndustry(replaceId)) return true
        if (market.hasIndustry(id)) {
            val ind = market.getIndustry(id)
            if (ind?.spec?.upgrade == replaceId) {
                ind?.startUpgrading()
                ind?.finishBuildingOrUpgrading()
            }
        } else {
            market.removeIndustry(id, null, false)
            if (replaceId != null) addIndustry(market, replaceId)
        }

        return true
    }
}