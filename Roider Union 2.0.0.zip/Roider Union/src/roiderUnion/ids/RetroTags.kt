package roiderUnion.ids

object RetroTags {
    const val UNION_HQ = "unionHQ"
    const val ARGOS = "argos"
    const val ROIDER = RoiderFactions.ROIDER_UNION
}