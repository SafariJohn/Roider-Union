package roiderUnion.ids

object HabGlows {
    const val BANDED = "banded"
    const val ASHARU = "asharu"
}