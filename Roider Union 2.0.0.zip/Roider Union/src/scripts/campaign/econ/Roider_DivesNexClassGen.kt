package scripts.campaign.econ

import com.fs.starfarer.api.campaign.econ.Industry
import exerelin.world.ExerelinProcGen
import exerelin.world.NexMarketBuilder
import exerelin.world.industry.IndustryClassGen
import roiderUnion.ids.RoiderIndustries

/**
 * Author: SafariJohn
 */
class Roider_DivesNexClassGen : IndustryClassGen(RoiderIndustries.DIVES, RoiderIndustries.UNION_HQ) {
    override fun canApply(entity: ExerelinProcGen.ProcGenEntity): Boolean {
        return if (entity.market.industries.size >= 12) false else super.canApply(entity)
    }

    override fun apply(entity: ExerelinProcGen.ProcGenEntity, instant: Boolean) {
        // If already have dives, upgrade to Union HQ
        if (entity.market.hasIndustry(RoiderIndustries.DIVES)) {
            val ind: Industry = entity.market.getIndustry(RoiderIndustries.DIVES)
            ind.startUpgrading()
            if (instant) ind.finishBuildingOrUpgrading()
            return
        }
        // build Union HQ directly
        NexMarketBuilder.addIndustry(entity.market, RoiderIndustries.UNION_HQ, this.id, instant)
        entity.numProductiveIndustries += 1
    }

    override fun canAutogen(): Boolean {
        return false
    }
}