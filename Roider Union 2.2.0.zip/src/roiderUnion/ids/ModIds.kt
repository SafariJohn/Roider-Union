package roiderUnion.ids

object ModIds {
    const val ROIDER_UNION = "roider"
    const val ROIDER_UNION_DEV = "roider_dev"
    const val LAZY_LIB = "lw_lazylib"
    const val MAGIC_LIB = "MagicLib"
    const val RETRO_LIB = "RetroLib"
    const val GRAPHICS_LIB = "shaderLib"
    const val NEXERELIN = "nexerelin"
    const val STARSHIP_LEGENDS = "sun_starship_legends"
}