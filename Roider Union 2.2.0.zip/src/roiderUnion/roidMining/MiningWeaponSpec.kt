package roiderUnion.roidMining

class MiningWeaponSpec(
    val id: String,
    val iceEfficiency: Float,
    val dustEfficiency: Float,
    val rockEfficiency: Float,
    val metalEfficiency: Float,
    val plutonEfficiency: Float
)