package roiderUnion.submarkets

import com.fs.starfarer.api.campaign.CargoAPI
import com.fs.starfarer.api.campaign.CoreUIAPI
import com.fs.starfarer.api.campaign.PlayerMarketTransaction
import com.fs.starfarer.api.campaign.SpecialItemData
import com.fs.starfarer.api.campaign.SubmarketPlugin.PlayerEconomyImpactMode
import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI
import com.fs.starfarer.api.impl.campaign.ids.Items
import com.fs.starfarer.api.impl.campaign.submarkets.BlackMarketPlugin
import com.fs.starfarer.api.impl.campaign.submarkets.OpenMarketPlugin
import com.thoughtworks.xstream.XStream
import roiderUnion.helpers.Helper
import roiderUnion.ids.Aliases
import roiderUnion.ids.RoiderIds
import roiderUnion.ids.RoiderIndustries
import java.util.*


class NomadSubmarketPlugin : BlackMarketPlugin() {
    companion object {
        const val QUANTITY_REDUCTION = 0.2f
        const val FUEL_MULT = 2f

        fun alias(x: XStream) {
            x.alias(Aliases.NOMMARK, NomadSubmarketPlugin::class.java)
        }
    }

    override fun isBlackMarket(): Boolean = false

    override fun getTariff(): Float = market.tariff.modifiedValue

    override fun getPlayerEconomyImpactMode(): PlayerEconomyImpactMode = PlayerEconomyImpactMode.PLAYER_SELL_ONLY

    override fun getStockpileLimit(com: CommodityOnMarketAPI?): Int {
        if (com == null) return 0
        var limit = OpenMarketPlugin.getBaseStockpileLimit(com)

        val random = Random(
            (market.id.hashCode() + submarket.specId.hashCode() + (Helper.sector?.clock?.month ?: 0) * 170000).toLong()
        )
        limit *= 0.9f + 0.2f * random.nextFloat()
        val sm = market.stabilityValue / 10f
        limit *= QUANTITY_REDUCTION * sm
        if (limit < 0) limit = 0f
        if (com.isFuel) limit *= FUEL_MULT
        return limit.toInt()
    }

    override fun updateCargoPrePlayerInteraction() {
        super.updateCargoPrePlayerInteraction()

        cargo?.removeItems(
            CargoAPI.CargoItemType.SPECIAL,
            SpecialItemData(Items.INDUSTRY_BP, RoiderIndustries.DIVES),
            1f
        )
        cargo?.removeItems(
            CargoAPI.CargoItemType.SPECIAL,
            SpecialItemData(RoiderIds.Roider_Items.DIVES_BP, RoiderIndustries.DIVES),
            1f
        )
        if (Helper.sector?.playerFaction?.knowsIndustry(RoiderIndustries.DIVES) == false) {
            cargo?.addSpecial(SpecialItemData(RoiderIds.Roider_Items.DIVES_BP, RoiderIndustries.DIVES), 1f)
        }
    }

    override fun reportPlayerMarketTransaction(transaction: PlayerMarketTransaction?) {}

    override fun getTooltipAppendix(ui: CoreUIAPI?): String? = null
}