package roiderUnion.retrofits.old.base

class BaseRetrofitModel : RetrofitPluginModel {

}
