package retroLib

object IDs {
    const val ILLUSTRATIONS = "illustrations"
    const val CONSTRUCTION = "orbital_construction"
}