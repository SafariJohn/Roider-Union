package retroLib.impl

enum class QueueState {
    EMPTY,
    ONE,
    MANY
}