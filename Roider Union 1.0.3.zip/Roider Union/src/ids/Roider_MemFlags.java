package ids;

/**
 * Author: SafariJohn
 */
public class Roider_MemFlags {
    // Retrofit managers are kept in their market's memory.
    public static final String RETROFITTER = "$roider_retrofitManager";

    // RetrofitAccess variables
    public static final String TALK_RETROFITS = "$roider_talkedAboutRetrofits";
    public static final String FEE_PAID = "$roider_retrofitFeePaid";
    public static final String ACCESS_FEE = "$roider_retrofitFee";
    public static final String STORAGE_FEE = "$roider_retrofitStorageFeeAdded";

    // Stored in the market's memory.
    public static final String UNION_HQ_FUNCTIONAL = "$roider_hq_functional";

    // Roider Union sub-faction commission
    public static final String ROIDER_COMMISSION = "$roider_commission";

    // Blocks dives and Union HQs from mining
    public static final String CLAIMED = "$roider_miningBlocked";

}
