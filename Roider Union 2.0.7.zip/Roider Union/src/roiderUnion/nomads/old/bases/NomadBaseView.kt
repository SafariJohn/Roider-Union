package roiderUnion.nomads.old.bases

class NomadBaseView(private val model: NomadBaseModel) {
}
