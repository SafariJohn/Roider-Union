package roiderUnion.econ

import com.fs.starfarer.api.campaign.StarSystemAPI
import com.fs.starfarer.api.campaign.econ.EconomyAPI.EconomyUpdateListener
import com.fs.starfarer.api.impl.campaign.ids.Commodities
import roiderUnion.helpers.Helper
import roiderUnion.helpers.Memory
import roiderUnion.ids.MemoryKeys

class DivesSupplyManager : EconomyUpdateListener {
    companion object {
        private val miningBonus = mutableMapOf<String, String>()

        fun getMiningBonus(system: StarSystemAPI, com: String): String? {
            if (miningBonus.isEmpty()) update()
            return miningBonus[system.baseName + com]
        }

        private fun update() {
            for (s in Helper.sector?.starSystems ?: emptyList()) {
                getMiningBonusFromMemory(s, Commodities.ORE)
                getMiningBonusFromMemory(s, Commodities.RARE_ORE)
                getMiningBonusFromMemory(s, Commodities.ORGANICS)
                getMiningBonusFromMemory(s, Commodities.VOLATILES)
            }
        }

        private fun getMiningBonusFromMemory(system: StarSystemAPI, com: String) {
            val c = Memory.getNullable(MemoryKeys.VOID_RESOURCE + com, system, { it is String }, { null }) as String?
            if (c != null) miningBonus[system.baseName + com] = c
        }
    }

    override fun economyUpdated() {
        update()
    }

    override fun isEconomyListenerExpired(): Boolean = false
    override fun commodityUpdated(commodityId: String?) {}
}