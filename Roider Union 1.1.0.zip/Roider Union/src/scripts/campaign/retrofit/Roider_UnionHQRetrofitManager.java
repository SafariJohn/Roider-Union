package scripts.campaign.retrofit;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import exerelin.utilities.ExerelinConfig;
import exerelin.utilities.ExerelinFactionConfig;
import ids.Roider_Ids.Roider_Factions;
import ids.Roider_Ids.Roider_Submarkets;
import scripts.campaign.retrofit.Roider_BaseRetrofitPlugin.RetrofitData;
import scripts.campaign.submarkets.Roider_UnionHQSubmarketPlugin;
import java.io.IOException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import scripts.Roider_ModPlugin;

/**
 * Author: SafariJohn
 */
public class Roider_UnionHQRetrofitManager extends Roider_BaseRetrofitManager {
    public static final String MASTER_MOD;
    static {
        if (Global.getSettings().getModManager().isModEnabled("roider_dev")) MASTER_MOD = "roider_dev";
        else MASTER_MOD = "roider";
    }

    public Roider_UnionHQRetrofitManager(String fitter, SectorEntityToken entity, FactionAPI faction) {
        super(fitter, entity, faction, MASTER_MOD);
    }

    @Override
    public void advanceImpl(float amount) {
        if (entity == null || entity.getMarket() == null || entity.getMarket().isPlanetConditionMarketOnly()) {
            endImmediately();
            return;
        }

        if (queued.isEmpty()) return;
        if (Global.getSector().isPaused()) return;

        if (faction.isAtBest(Factions.PLAYER, RepLevel.SUSPICIOUS)) {
            queued.get(0).pause("your reputation is too low");
            return;
        }

        SubmarketAPI unionHQ = entity.getMarket().getSubmarket(Roider_Submarkets.UNION_MARKET);
        if (unionHQ == null) return;

        boolean retrofitsEnabled = ((Roider_UnionHQSubmarketPlugin) unionHQ.getPlugin()).isEnabled(null);
        if (!retrofitsEnabled) {
            if (!queued.isEmpty()) {
                queued.get(0).pause("the Union HQ is disrupted");
            }

            return;
        } else {
            queued.get(0).unpause();
        }

        super.advanceImpl(amount);
    }

    /**
     * Only call this when necessary.
     * @return
     */
    @Override
    public List<RetrofitData> getRetrofits() {
        // Load master retrofits
        // This prevents other mods from overwriting the master
        List<RetrofitData> retrofits = new ArrayList<>();
        org.json.JSONArray csv = null;

        try {
            csv = Global.getSettings().loadCSV("data/retrofit/retrofits.csv", MASTER_MOD);
        } catch (IOException | JSONException ex) {
            Logger.getLogger(Roider_UnionHQRetrofitManager.class.getName()).log(Level.SEVERE, null, ex);
        }

        if (csv == null) return retrofits;

        try {
            for (int i = 0; i < csv.length(); i++) {
                JSONObject o = csv.getJSONObject(i);
                if (!o.getString("fitter").equals(fitter)) continue;

                String id = o.getString("id");
                String source = o.getString("source");
                String target = o.getString("target");
                double cost = o.getInt("cost");
                double time = Math.max(0, o.getDouble("time"));
                RepLevel rep = getReputation(o.getInt("reputation"));
                boolean commission = o.getBoolean("commission");

                try {
                    Global.getSettings().getHullSpec(source);
                    Global.getSettings().getHullSpec(target);
                } catch (Exception ex) { continue; }

                // Apply Nexerelin's tariff changes. Might pickup other ones, idk
                String factionId = Roider_Factions.ROIDER_UNION;
                float tariff = Global.getSector().getFaction(factionId).getTariffFraction();
                cost /= 1f + tariff; // Prices assume default vanilla tariff
                if (Roider_ModPlugin.hasNexerelin) {
                    ExerelinFactionConfig conf = ExerelinConfig.getExerelinFactionConfig(factionId);
                    tariff *= ExerelinConfig.baseTariffMult;
                    tariff *= conf.tariffMult;
                }
                cost *= 1f + tariff;

                retrofits.add(new RetrofitData(id, fitter, source, target, cost, time, rep, commission));
            }
        } catch (JSONException ex) {
            Logger.getLogger(Roider_UnionHQRetrofitManager.class.getName()).log(Level.SEVERE, null, ex);
        }


        // Load any retrofits added by other mods
        try {
            csv = Global.getSettings().getMergedSpreadsheetDataForMod("id", "data/retrofit/retrofits.csv", MASTER_MOD);
        } catch (IOException | JSONException ex) {
            Logger.getLogger(Roider_UnionHQRetrofitManager.class.getName()).log(Level.SEVERE, null, ex);
        }

        if (csv == null) return retrofits;

        try {
            for (int i = 0; i < csv.length(); i++) {
                JSONObject o = csv.getJSONObject(i);

                if (!o.getString("fitter").equals(fitter)) continue;

                String id = o.getString("id");
                // Don't add retrofits that are already defined by the master mod.
                if (alreadyLoaded(retrofits, id)) continue;

                String source = o.getString("source");
                String target = o.getString("target");
                double cost = o.getInt("cost");
                double time = Math.max(0, o.getDouble("time"));
                RepLevel rep = getReputation(o.getInt("reputation"));
                boolean commission = o.getBoolean("commission");

                try {
                    Global.getSettings().getHullSpec(source);
                    Global.getSettings().getHullSpec(target);
                } catch (Exception ex) { continue; }

                // Apply Nexerelin's tariff changes. Might pickup other ones, idk
                String factionId = Roider_Factions.ROIDER_UNION;
                float tariff = Global.getSector().getFaction(factionId).getTariffFraction();
                if (Roider_ModPlugin.hasNexerelin) {
                    ExerelinFactionConfig conf = ExerelinConfig.getExerelinFactionConfig(factionId);
                    tariff *= ExerelinConfig.baseTariffMult;
                    tariff *= conf.tariffMult;
                }
                cost *= 0.7f + tariff; // Prices assume 30% default

                retrofits.add(new RetrofitData(id, fitter, source, target, cost, time, rep, commission));
            }
        } catch (JSONException ex) {
            Logger.getLogger(Roider_UnionHQRetrofitManager.class.getName()).log(Level.SEVERE, null, ex);
        }

        return retrofits;
    }

    private boolean alreadyLoaded(List<RetrofitData> retrofits, String id) throws JSONException {
        for (RetrofitData data : retrofits) {
            if (data.id.equals(id)) return true;
        }

        return false;
    }
}
