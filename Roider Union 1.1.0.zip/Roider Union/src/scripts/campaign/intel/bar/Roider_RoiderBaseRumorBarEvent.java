package scripts.campaign.intel.bar;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.characters.FullName.Gender;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.intel.bar.PortsideBarData;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.BaseBarEvent;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import ids.Roider_Ids.Roider_Industries;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import scripts.campaign.bases.Roider_RoiderBaseIntelV2;
import scripts.campaign.bases.Roider_RoiderBaseManager;

public class Roider_RoiderBaseRumorBarEvent extends BaseBarEvent {
	protected Roider_RoiderBaseIntelV2 intel;
    protected List<MarketAPI> potentialBars;
    protected String uid;

	public Roider_RoiderBaseRumorBarEvent(Roider_RoiderBaseIntelV2 intel) {
		this.intel = intel;
        uid = Misc.genUID();

        potentialBars = new ArrayList<>();

        WeightedRandomPicker<MarketAPI> picker = new WeightedRandomPicker<>();
        for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
            float weight = 0;

            if (market.hasIndustry(Roider_Industries.DIVES)) weight = 1f;
            if (market.hasIndustry(Roider_Industries.UNION_HQ)) weight = 2f;

//            if (market.getFaction().isHostileTo(Factions.INDEPENDENT)) weight *= 2;

            if (weight > 0) picker.add(market, weight);
        }

        float numRumors = 1f + new Random().nextFloat() * 3f;
        while (numRumors > 0) {
            potentialBars.add(picker.pickAndRemove());
            numRumors--;
        }
	}

	public boolean shouldShowAtMarket(MarketAPI market) {
		if (!super.shouldShowAtMarket(market)) return false;

        String rumorId = (String) market.getMemoryWithoutUpdate()
                    .get(Roider_RoiderBaseManager.RUMOR_HERE);

        if (rumorId != null) {
            return rumorId.equals(uid);
        }

        if (potentialBars.contains(market)) {
            market.getMemoryWithoutUpdate().set(Roider_RoiderBaseManager.RUMOR_HERE, uid);
            return true;
        }

        return false;
	}

	@Override
	public boolean shouldRemoveEvent() {
		return intel.isEnding() || intel.isEnded() || intel.isPlayerVisible();
	}



	transient protected boolean done = false;
	transient protected Gender gender;

	@Override
	public void addPromptAndOption(InteractionDialogAPI dialog) {
		super.addPromptAndOption(dialog);

		gender = Gender.MALE;
		if ((float) Math.random() > 0.5f) {
			gender = Gender.FEMALE;
		}

		String himOrHer = "him";
		if (gender == Gender.FEMALE) himOrHer = "her";

		TextPanelAPI text = dialog.getTextPanel();
		text.addPara("A hard-up roider sits at the bar, downing shots " +
                    "of what looks like the cheapest liquor available.");

		dialog.getOptionPanel().addOption(
				"Approach the roider and offer to buy " + himOrHer
                            + " something more palatable", this);
	}

	@Override
	public void init(InteractionDialogAPI dialog) {
		super.init(dialog);

		String himOrHerSelf = "himself";
		if (gender == Gender.FEMALE) himOrHerSelf = "herself";

		TextPanelAPI text = dialog.getTextPanel();
		text.addPara("You keep the drinks going and mostly just listen, " +
					 "letting the roider unburden " + himOrHerSelf + ".");

        MarketAPI market = dialog.getInteractionTarget().getMarket();
		PersonAPI person = market.getFaction().createRandomPerson(gender);
		dialog.getVisualPanel().showPersonInfo(person, true);

		done = true;
		intel.makeKnown();
		intel.sendUpdate(Roider_RoiderBaseIntelV2.DISCOVERED_PARAM, text);
        market.getMemoryWithoutUpdate().unset(Roider_RoiderBaseManager.RUMOR_HERE);

		PortsideBarData.getInstance().removeEvent(this);
	}


	@Override
	public void optionSelected(String optionText, Object optionData) {
	}

	@Override
	public boolean isDialogFinished() {
		return done;
	}
}



