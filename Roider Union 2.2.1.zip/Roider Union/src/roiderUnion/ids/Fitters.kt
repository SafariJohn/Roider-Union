package roiderUnion.ids

object Fitters {
    const val ALL = "roider_all"
    const val FULL = "roider_full"
    const val LIGHT = "roider_light"
    const val ARGOS = "roider_argos"
}