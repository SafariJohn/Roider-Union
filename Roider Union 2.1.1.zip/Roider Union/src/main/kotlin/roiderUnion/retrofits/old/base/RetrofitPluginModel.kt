package roiderUnion.retrofits.old.base

interface RetrofitPluginModel {
}