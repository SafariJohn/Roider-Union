package roiderUnion.ids

object Icons {
    const val NOMAD_BASE = "roider_base"
}