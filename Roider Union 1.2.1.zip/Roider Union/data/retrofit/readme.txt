id: unique id
fitter: retrofits with the same fitter are available at the same locations
source: pre-retrofit ship hull id
target: post-retrofit ship hull id
cost: in credits = targetValue * 1.5 - sourceValue / 5
time: in days
reputation:
	 4: COOPERATIVE
	 3: FRIENDLY
	 2: WELCOMING
	 1: FAVORABLE
	 0: NEUTRAL
	-1: SUSPICIOUS
	-2: INHOSPITABLE
	-3: HOSTILE
	-4: VENGEFUL
commission: true or false
