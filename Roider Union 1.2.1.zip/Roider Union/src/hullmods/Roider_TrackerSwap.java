package hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShipAPI;
import ids.Roider_Ids.Roider_Hullmods;
import java.util.HashSet;
import java.util.Set;

/**
 * Author: SafariJohn
 */
public class Roider_TrackerSwap extends BaseHullMod {

    public static final Set<String> SHIPS = new HashSet<>();
    static {
        SHIPS.add("roider_sheriff");
        SHIPS.add("roider_cowboy");
        SHIPS.add("roider_ranch");
    }

    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        // Handled in Roider_MIDAS instead.
    }

    @Override
    public String getUnapplicableReason(ShipAPI ship) {
        if (ship.getVariant().hasHullMod(Roider_Hullmods.GLITZ_SWITCH)) {
            return "Drones are already switched";
        }


        return "Can only be applied to ships with built-in Breaker drones";
    }

    @Override
    public boolean isApplicableToShip(ShipAPI ship) {
        if (ship.getVariant().hasHullMod(Roider_Hullmods.GLITZ_SWITCH)) return false;

        return SHIPS.contains(ship.getHullSpec().getBaseHullId());
    }

}
