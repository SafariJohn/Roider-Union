package scripts;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.intel.bar.PortsideBarData;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.BaseBarEvent;
import exerelin.campaign.ExerelinSetupData;
import exerelin.campaign.PlayerFactionStore;
import exerelin.campaign.SectorManager;
import ids.Roider_Ids.Roider_Factions;
import org.dark.shaders.light.LightData;
import org.dark.shaders.util.ShaderLib;
import org.dark.shaders.util.TextureData;
import scripts.campaign.Roider_FringeStationCleaner;
import scripts.campaign.bases.Roider_RoiderBaseManager;
import scripts.campaign.intel.bar.Roider_RetrofitBarEvent;
import scripts.campaign.retrofit.blueprints.Roider_PiratesLearnBPsScript;
import scripts.world.Roider_Gen;

public class Roider_ModPlugin extends BaseModPlugin {
    public static boolean hasNexerelin = false;

    @Override
    public void onApplicationLoad() {
        boolean hasLazyLib = Global.getSettings().getModManager().isModEnabled("lw_lazylib");
        if (!hasLazyLib) throw new RuntimeException("Roider Union requires LazyLib!");

        boolean hasMagicLib = Global.getSettings().getModManager().isModEnabled("MagicLib");
        if (!hasMagicLib) throw new RuntimeException("Roider Union requires MagicLib!");

        boolean hasGraphicsLib = Global.getSettings().getModManager().isModEnabled("shaderLib");
        if (hasGraphicsLib) {
            ShaderLib.init();
            LightData.readLightDataCSV("data/lights/roider_light_data.csv");
            TextureData.readTextureDataCSV("data/lights/roider_texture_data.csv");
        }

        hasNexerelin = Global.getSettings().getModManager().isModEnabled("nexerelin");

        boolean hasfastsave = Global.getSettings().getModManager().isModEnabled("fastsave");
        if (hasfastsave) throw new RuntimeException("Roider Union is not compatible with the Fast Save mod!");
    }


    @Override
    public void onNewGame() {
        SectorAPI sector = Global.getSector();

        Roider_Gen.initFactionRelationships(sector);

		if (!hasNexerelin || SectorManager.getManager().isCorvusMode()) {
            Roider_Gen.generate(sector);
        }
    }

    @Override
    public void onNewGameAfterEconomyLoad() {
        SectorAPI sector = Global.getSector();

		if (!hasNexerelin || SectorManager.getManager().isCorvusMode()) {

            Roider_Gen.addCoreDives(sector);

            Roider_Gen.assignCustomAdmins();
            Roider_Gen.assignRandomAdmins();
        }

        if (!sector.hasScript(Roider_PiratesLearnBPsScript.class)) {
            sector.getEconomy().addUpdateListener(new Roider_PiratesLearnBPsScript(Global.
                        getSector().getFaction(Factions.PIRATES)));
        }

        BaseBarEvent event = new Roider_RetrofitBarEvent();
        PortsideBarData.getInstance().addEvent(event);

        if (nexerelinRoidersEnabled()) {
            Roider_Gen.placeFringeRoiderHQs(sector);

            if (!sector.hasScript(Roider_RoiderBaseManager.class)) {
                sector.addScript(new Roider_RoiderBaseManager());
            }
        }
    }

    @Override
    public void onNewGameAfterTimePass() {
        if (hasNexerelin && !SectorManager.getManager().isCorvusMode()
                    && nexerelinRoidersEnabled()) {
            Roider_Gen.addNexRandomModeDives();
            Roider_Gen.addNexRandomRockpiper();
        }
    }

    @Override
    public void onGameLoad(boolean newGame) {
        if (!newGame) {
            Roider_FringeStationCleaner.removeOrphanedFringeStations(Global.getSector());
        }
    }

    /**
     * Detects whether the Roider Union faction is disabled in Nexerelin random mode.
     * @return
     */
    public static boolean nexerelinRoidersEnabled() {
        if (!hasNexerelin || SectorManager.getManager().isCorvusMode()) return true;

        ExerelinSetupData data = ExerelinSetupData.getInstance();
        boolean roidersEnabled = data.factions.get(Roider_Factions.ROIDER_UNION);

		String playerFaction = PlayerFactionStore.getPlayerFactionIdNGC();

        if (playerFaction.equals(Roider_Factions.ROIDER_UNION)) return true;

        return roidersEnabled;
    }
}