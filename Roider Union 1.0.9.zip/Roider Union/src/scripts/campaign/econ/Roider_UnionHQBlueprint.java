package scripts.campaign.econ;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.campaign.impl.items.IndustryBlueprintItemPlugin;
import ids.Roider_Ids.Roider_Industries;

/**
 * Author: SafariJohn
 */
public class Roider_UnionHQBlueprint extends IndustryBlueprintItemPlugin {
	@Override
	public void init(CargoStackAPI stack) {
		this.stack = stack;
		industry = Global.getSettings().getIndustrySpec(Roider_Industries.UNION_HQ);
	}

    @Override
    public int getPrice(MarketAPI market, SubmarketAPI submarket) {
		if (industry != null) {
            return 200000;
//            return (int) (250000f / 1.2f) + 1; // bullshit magic numbers to get 350k

//			float base = super.getPrice(market, submarket);
//			return (int) ((base + industry.getCost() * getItemPriceMult()) / 4.5);
		}
		return super.getPrice(market, submarket);
    }

}
