package retroLib.api

interface RetrofitPluginView {
    fun init()
    fun showOptionResult()
    fun showMouseOverResult()
}