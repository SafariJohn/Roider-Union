package retroLib.impl

enum class PickSourcesOptionState {
    NORMAL,
    NO_TARGET,
    NONE_AVAILABLE,
    NOT_ALLOWED,
    ILLEGAL

}
