package retroLib

object ModIds {
    const val LAZY_LIB = "lw_lazylib"
    const val MAGIC_LIB = "MagicLib"
    const val NEXERELIN = "nexerelin"
    const val STARSHIP_LEGENDS = "sun_starship_legends"
}