package roiderUnion.ids

object Categories {
    const val ROIDER = "roider"
    const val MISC = "misc"
    const val ILLUSTRATIONS = "illustrations"
    const val HAB_GLOWS = "hab_glows"
    const val INDUSTRY = "industry"
    const val CHARACTERS = "characters"
    const val INTEL = "intel"
}