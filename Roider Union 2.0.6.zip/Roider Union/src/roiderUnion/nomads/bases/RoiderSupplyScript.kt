package roiderUnion.nomads.bases

import com.fs.starfarer.api.campaign.SectorEntityToken
import com.fs.starfarer.api.campaign.econ.CommoditySourceType
import com.fs.starfarer.api.campaign.econ.EconomyAPI.EconomyUpdateListener
import com.fs.starfarer.api.impl.campaign.ids.Stats
import com.thoughtworks.xstream.XStream
import roiderUnion.helpers.ExternalStrings
import roiderUnion.helpers.Helper
import roiderUnion.ids.Aliases
import roiderUnion.ids.MemoryKeys
import kotlin.math.roundToInt

class RoiderSupplyScript(private val base: SectorEntityToken) : EconomyUpdateListener {
    companion object {
        fun alias(x: XStream) {
            val jClass = RoiderSupplyScript::class.java
            x.alias(Aliases.SPLYSCRIPT, jClass)
            x.aliasAttribute(jClass, "base", "b")
            x.aliasAttribute(jClass, "market", "m")
            x.aliasAttribute(jClass, "modId", "id")
        }
    }

    private val market = base.market
    private val modId = market.id + MemoryKeys.NOMAD_BASE

    override fun commodityUpdated(commodityId: String?) {
        val com = market.getCommodityData(commodityId) ?: return
        val supply = com.availableStat ?: return

        var available = supply.baseValue.roundToInt()
        supply.flatMods?.values
            ?.filterNot { it.source == modId }
            ?.filter { it.value >= 0 }
            ?.forEach { available += it.value.roundToInt() }
        var maxFactionAvailable = -1
        var maxAvailable = -1
        val coreMarkets = Helper.sector?.economy?.getMarketsInGroup(null) ?: emptyList()
        for (m in coreMarkets) {
            val c = m.getCommodityData(commodityId) ?: continue
            if (m.factionId == market.factionId) {
                if (c.maxSupply > maxFactionAvailable) maxFactionAvailable = c.maxSupply
            } else {
                if (c.maxSupply > maxAvailable) maxAvailable = c.maxSupply
            }
        }
        coreMarkets.forEach {
        }
        if (com.maxDemand > available) {
            if (maxFactionAvailable >= com.maxDemand) {
                val supplyBonus = maxFactionAvailable.coerceAtMost(com.maxDemand) - available
                com.commodityMarketData.getMarketShareData(market).source = CommoditySourceType.IN_FACTION
                com.maxSupply = maxFactionAvailable.coerceAtMost(com.maxDemand) // Not ideal bc it makes it "produced", but close enough to functional
                supply.modifyFlat(modId, supplyBonus.toFloat(), ExternalStrings.NOMAD_SUPPLY_IN_FACTION)
            } else {
                val supplyBonus = maxAvailable.coerceAtMost(com.maxDemand) - available
                com.commodityMarketData.getMarketShareData(market).source = CommoditySourceType.GLOBAL
                supply.modifyFlat(modId, supplyBonus.toFloat(), ExternalStrings.NOMAD_SUPPLY)
            }
        }

        market.reapplyIndustries()
    }

    override fun economyUpdated() {
        var qualityBonus = 0f
        var fleetSizeBonus = 1f
        when (NomadBaseLevelTracker.getLevel(base)) {
            NomadBaseLevel.STARTING -> {
                qualityBonus = 0f
                fleetSizeBonus = 0.2f
            }
            NomadBaseLevel.ESTABLISHED -> {
                qualityBonus = 0.2f
                fleetSizeBonus = 0.3f
            }
            NomadBaseLevel.BATTLESTATION -> {
                qualityBonus = 0.2f
                fleetSizeBonus = 0.4f
            }
            NomadBaseLevel.SHIPWORKS -> {
                qualityBonus = 0.2f
                fleetSizeBonus = 0.5f
            }
            NomadBaseLevel.HQ -> {
                qualityBonus = 0.2f
                fleetSizeBonus = 0.75f
            }
            NomadBaseLevel.CAPITAL -> {
                qualityBonus = 0.0f
                fleetSizeBonus = 0.75f
            }
        }

        market.stats?.dynamic?.getMod(Stats.FLEET_QUALITY_MOD)?.modifyFlatAlways(
            modId, qualityBonus,
            ExternalStrings.NOMAD_DEVELOPMENT
        )

        market.stats?.dynamic?.getMod(Stats.COMBAT_FLEET_SIZE_MULT)?.modifyFlatAlways(
            modId,
            fleetSizeBonus,
            ExternalStrings.NOMAD_DEVELOPMENT
        )
    }

    override fun isEconomyListenerExpired(): Boolean = base.isExpired
}