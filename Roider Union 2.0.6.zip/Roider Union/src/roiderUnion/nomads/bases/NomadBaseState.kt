package roiderUnion.nomads.bases

enum class NomadBaseState {
    KNOWN,
    DISCOVERED,
    LOC_UNKNOWN,
    DESTROYED,
    ABANDONED
}