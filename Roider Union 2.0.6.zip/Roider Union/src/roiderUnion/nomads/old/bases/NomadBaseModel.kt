package roiderUnion.nomads.old.bases

import com.fs.starfarer.api.campaign.SectorEntityToken
import roiderUnion.nomads.NomadsData

class NomadBaseModel(val baseEntity: SectorEntityToken) {
    var group: NomadsData? = null
}
